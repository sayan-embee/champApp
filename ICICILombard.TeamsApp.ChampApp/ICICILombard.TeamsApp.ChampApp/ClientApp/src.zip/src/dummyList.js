export const DummyList = [
    {name:"Sayan"},
    {name:"Alok"},
    {name:"Sourav"},
    {name:"kaustav"}
]